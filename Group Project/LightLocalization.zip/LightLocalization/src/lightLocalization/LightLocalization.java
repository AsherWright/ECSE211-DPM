package lightLocalization;

import lejos.hardware.Button;
import lejos.hardware.ev3.LocalEV3;
import lejos.hardware.lcd.TextLCD;
import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.Port;
import lejos.hardware.sensor.EV3ColorSensor;
import lejos.robotics.SampleProvider;

public class LightLocalization {
	
		// Static Resources:
		// Left motor connected to output A
		// Right motor connected to output D
		private static final EV3LargeRegulatedMotor leftMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("A"));
		private static final EV3LargeRegulatedMotor rightMotor = new EV3LargeRegulatedMotor(LocalEV3.get().getPort("D"));
		private static final Port colorPort = LocalEV3.get().getPort("S1");
		// Constants

		public static void main(String[] args) {
			int buttonChoice;

			// some objects that need to be instantiated
			
			final TextLCD t = LocalEV3.get().getTextLCD();
			
			Odometer odometer = new Odometer(leftMotor, rightMotor, 0, true);
			OdometryDisplay odometryDisplay = new OdometryDisplay(odometer,t);
			Navigation navigation = new Navigation(odometer);
			
			odometer.setPosition (new double[] {0.0, 0.0, 0.0} , new boolean[] {true, true, true} );
						
			EV3ColorSensor colorSensor = new EV3ColorSensor(colorPort);
			colorSensor.setFloodlight(lejos.robotics.Color.WHITE);
			SampleProvider colorValue = colorSensor.getMode("Red");			// colorValue provides samples from this instance
			float[] colorData = new float[colorValue.sampleSize()];			// colorData is the buffer in which data are returned
			
			LightLocalizer lsl = new LightLocalizer(odometer, colorValue, colorData, navigation);
			
			do {
				// clear the display
				t.clear();

				// ask the user whether the motors should drive in a square or float
				t.drawString("< Left | Right >", 0, 0);
				t.drawString("       |        ", 0, 1);
				t.drawString(" Float | Light  ", 0, 2);
				t.drawString("motors | Localization", 0, 3);
				t.drawString("       |        ", 0, 4);

				buttonChoice = Button.waitForAnyPress();
			} while (buttonChoice != Button.ID_LEFT
					&& buttonChoice != Button.ID_RIGHT);

			if (buttonChoice == Button.ID_LEFT) {
				
				leftMotor.forward();
				leftMotor.flt();
				rightMotor.forward();
				rightMotor.flt();
				
				odometer.start();
				odometryDisplay.start();
				
			} else {
				odometer.start();
				odometryDisplay.start();
				lsl.doLocalization();
			}
			
			while (Button.waitForAnyPress() != Button.ID_ESCAPE);
			System.exit(0);
		}

}
