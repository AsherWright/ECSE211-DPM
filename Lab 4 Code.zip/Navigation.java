public class Navigation {

	private Odometer odo;
	
	public Navigation(Odometer odo) {
		this.odo = odo;
	}
	
	public void travelTo(double x, double y) {
		
	}
	
	public void turnTo(double angle) {
		
	}
	
}
